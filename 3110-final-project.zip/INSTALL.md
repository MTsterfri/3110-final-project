For information on installing OCaml, 
see https://cs3110.github.io/textbook/chapters/preface/install.html
No extra installation is needed for this project.

1. Enter into /word_hex folder. Can be done with 'cd word_hex'
2. Type 'dune build'
To run program:
  3. Type `make word_hex` to run the program.
To test program:
  3. Type `make test` to test the program.