For information on installing OCaml, 
see https://cs3110.github.io/textbook/chapters/preface/install.html

raylib-ocaml can be installed via opam:
on command line type `opam install raylib`

yojson can be installed via opam:
on command line type `opam install yojson.2.1.0`

1. Enter into /word_hex folder. Can be done with 'cd word_hex'
2. Type 'dune build'
To run program:
  3. Type `make word_hex` to run the program.
To test program:
  3. Type `make test` to test the program.